// Solicită utilizatorului să introducă valoarea pentru A
let a = prompt("Introduceți valoarea pentru \"A\"");

// Solicită utilizatorului să introducă valoarea pentru B
let b = prompt("Introduceți valoarea pentru \"B\"");

// Convertim valorile introduse de la utilizator în numere
a = parseFloat(a);
b = parseFloat(b);

// Verificăm dacă valorile introduse sunt numere valide
if (isNaN(a) || isNaN(b)) {
    alert("Introduceți valori numerice valide pentru A și B.");
} else {
    // Afișăm valorile și rezultatele operațiilor în fereastră utilizând alert
    alert("######## VALUES #######\n" +
          "a = " + a + "\n" +
          "b = " + b + "\n" +
          "###### OPERATIONS #####\n" +
          "a * b = " + (a * b) + "\n" +
          "a / b = " + (a / b) + "\n" +
          "a + b = " + (a + b) + "\n" +
          "a - b = " + (a - b) + "\n" +
          "########################");
}

// BONUS: Afișăm același lucru într-un document HTML utilizând document.write
document.write("<h2>######## VALUES #######</h2>");
document.write("<p>a = " + a + "</p>");
document.write("<p>b = " + b + "</p>");
document.write("<h2>###### OPERATIONS #####</h2>");
document.write("<p>a * b = " + (a * b) + "</p>");
document.write("<p>a / b = " + (a / b) + "</p>");
document.write("<p>a + b = " + (a + b) + "</p>");
document.write("<p>a - b = " + (a - b) + "</p>");
document.write("<h2>########################</h2>");
