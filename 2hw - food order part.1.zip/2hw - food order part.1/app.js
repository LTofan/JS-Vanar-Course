// Meniu
let food_1_name = "Pizza";
let food_1_price = 75.00;

let food_2_name = "Salad";
let food_2_price = 25.00;

// Adaugă mai multe "item"-uri așa cum ai specificat

// Cantități comandate de la utilizator
let food_1_quantity = parseInt(prompt(`How many "${food_1_name}" do you want?`));
let food_2_quantity = parseInt(prompt(`How many "${food_2_name}" do you want?`));

// Calculul costurilor pentru fiecare pozitie
let cost_1 = food_1_price * food_1_quantity;
let cost_2 = food_2_price * food_2_quantity;

// Calculul costului total
let totalCost = cost_1 + cost_2;

// Verifică dacă costul total depășește 200 pentru livrare gratuită
let free_delivery = totalCost > 200;

// Afișează nota de plată
alert("############### BILL ####################\n" +
      `1. "${food_1_name}" x ${food_1_quantity} = ${cost_1.toFixed(2)}\n` +
      `2. "${food_2_name}" x ${food_2_quantity} = ${cost_2.toFixed(2)}\n` +
      "-----------------------------------------\n" +
      `Total: ${totalCost.toFixed(2)}\n` +
      `Free delivery: ${free_delivery}\n` +
      "############### BILL ####################");
