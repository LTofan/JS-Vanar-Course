// Selecting the element with the ID 'notifications'
let notifications = document.querySelector('#notifications');

// Selecting buttons by their IDs
let success = document.getElementById('success');
let error = document.getElementById('error');
let warning = document.getElementById('warning');
let info = document.getElementById('info');

// Function to create and display a toast notification
function createToast(type, icon, title, text) {
    // Creating a new 'div' element for the toast
    let newToast = document.createElement('div');
    // Setting the inner HTML of the new 'div' with a template literal
    newToast.innerHTML = `
        <div class="toast ${type}">
            <i class="${icon}"></i>
            <div class="content">
                <div class="title">${title}</div>
                <span>${text}</span>
            </div>
            <i class="fas fa-times" onclick="(this.parentElement).remove()"></i>
        </div>`;
    // Appending the new toast to the notifications container
    notifications.appendChild(newToast);
    // Setting a timeout to remove the toast after 5000 milliseconds (5 seconds)
    newToast.timeOutc = setTimeout(
        () => newToast.remove(), 5000
    );
}

// Event handler for the 'Success' button click
success.onclick = function () {
    // Defining data for the success toast
    let type = 'success';
    let icon = 'fas fa-check-circle';
    let title = 'Success';
    let text = 'Success is a journey, not just a destination.';
    // Calling the createToast function with the defined data
    createToast(type, icon, title, text);
};

// Event handler for the 'Error' button click
error.onclick = function () {
    // Defining data for the error toast
    let type = 'error';
    let icon = 'fas fa-exclamation-circle';
    let title = 'Error';
    let text = 'View errors as feedback.';
    // Calling the createToast function with the defined data
    createToast(type, icon, title, text);
};

// Event handler for the 'Warning' button click
warning.onclick = function () {
    // Defining data for the warning toast
    let type = 'warning';
    let icon = 'fas fa-bomb';
    let title = 'Warning';
    let text = 'Warnings can prevent future challenges.';
    // Calling the createToast function with the defined data
    createToast(type, icon, title, text);
};

// Event handler for the 'Info' button click
info.onclick = function () {
    // Defining data for the info toast
    let type = 'info';
    let icon = 'fas fa-info-circle';
    let title = 'Info';
    let text = 'Organize and prioritize information.';
    // Calling the createToast function with the defined data
    createToast(type, icon, title, text);
};

